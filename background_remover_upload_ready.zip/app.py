from flask import Flask, request, send_file
from rembg import remove
from flask_cors import CORS
import io

app = Flask(__name__)
CORS(app)

@app.route('/remove-bg', methods=['POST'])
def remove_bg():
    image_file = request.files['image']
    input_bytes = image_file.read()
    output_bytes = remove(input_bytes)

    return send_file(
        io.BytesIO(output_bytes),
        mimetype='image/png',
        as_attachment=True,
        download_name='no-background.png'
    )

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)