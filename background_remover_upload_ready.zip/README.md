# Background Remover Tool

A free tool to remove backgrounds from images using Python, Flask, and rembg.

## 🌐 Live Demo (after deploy)
- **Frontend**: https://YOUR_USERNAME.github.io/background-remover/
- **Backend**: https://your-api-name.onrender.com/remove-bg

## 🚀 Deployment Instructions

### 1. Create GitHub Repo
Push this folder to a GitHub repo called `background-remover`.

### 2. Deploy Backend on Render

1. Go to https://render.com and create a new Web Service.
2. Connect your GitHub repo.
3. Use the following settings:
   - **Build Command**: `pip install -r requirements.txt`
   - **Start Command**: `python app.py`
   - **Environment**: Python 3
   - **Port**: 5000

4. Once deployed, note the backend URL and replace it in `index.html`.

### 3. Deploy Frontend on GitHub Pages

1. Commit and push changes to GitHub.
2. Go to your repo → **Settings → Pages**
3. Choose:
   - Source: `main` or `master`
   - Folder: `/root`
4. Save and visit: `https://YOUR_USERNAME.github.io/background-remover/`

## 🧠 Notes
- This uses `rembg` for AI background removal.
- The HTML uses JavaScript `fetch` to POST to the Flask backend.

## 🛠 Tech Stack
- HTML/CSS/JavaScript
- Python + Flask + rembg
- GitHub Pages
- Render.com (Free hosting)